<template>
  <div id="app">
    {{getCount}}
    <button @click="actincrease">同步+</button>
     <button @click="asyncincrease">异步+</button>
      是否成年： {{$store.getters.isAudlt}}
      ---
      是否成年： {{isAudlt}}
      ---
    <!--   是否成年： {{vueIsAudlt}}-->
    <img src="./assets/logo.png">
  </div>
</template>

<script>
  import {mapGetters,mapActions} from 'vuex'
  export default{


    methods:mapActions([ 'actincrease'  ,  'asyncincrease'])
    /*methods:{
        countinc(){
          //$store是一个全局对象
         return   this.$store.dispatch('actincrease')
        },
        countincAsync(){
            return   this.$store.dispatch('asyncincrease')
        }

    }*/,

  computed:mapGetters({
      isAudlt :'isAudlt' , //将store.js中getters中的isAudlt()映射成isAudlt对象
    getCount:'getCount'
  })

    // computed:{
    //     vueIsAudlt(){
    //       return this.$store.getters.isAudlt ;
    //     }

    // }

  }

</script>