import Vue from 'vue'
//npm install --save vux
import Vuex from 'vuex'

Vue.use(Vuex)

//共享变量
const state = {
    count : 0 
}

//直接操作共享变量 的对象
const mutations={
    //自增
    mulincrease(state){
          state.count ++ ;
    }
}

//操作mutations的对象
const actions={
    //同步，自增
    actincrease({commit}){  // 
        commit('mulincrease');
    },
  
    //异步，自增
    asyncincrease({commit}){
        //2秒之后再执行 ，模拟业务逻辑
        setTimeout( ()=>{
            commit('mulincrease') },2000 )
    }
}

    //如果要对 共享变量state.count计算，则开源使用getters
const getters={
    //是否成年
    isAudlt(){
       return  state.count>=18 ? '成年':'未成年'
    },
    getCount(){
        return  state.count
    }

}

//将store.js中的对象 暴露给外界，用于其他组件的共享
export default   new Vuex.Store({
    state,
    mutations,
    actions,
    getters
})