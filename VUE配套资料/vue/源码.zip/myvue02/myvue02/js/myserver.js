const http =  require('http') 
const urlModule =  require('url')   

//localhost:8080/myrequest?cb=myshow
//localhost:8080/myrequest2
//创建服务
let server = http.createServer();
//servlet: doGet(request,resposne)
server.on('request',  function(req,res){
    console.log('abcc')
    const { pathname ,query }  =   urlModule.parse( req.url ,true)
   if( pathname == '/myrequest'){
        var data =  {
            id : 1,
            name :"zs",
            age :23 
        }
        //响应到哪里？
        //localhost:8080/myrequest?cb=myshow
        //myshow(data)   //data->json
        //响应到：myshow方法，并响应的数据：data
        var result = `${query.cb}( ${JSON.stringify(data)}  )` 
        res.end(result)  
   }
})

server.listen(8888,function(){
    console.log('sever running...')
})

