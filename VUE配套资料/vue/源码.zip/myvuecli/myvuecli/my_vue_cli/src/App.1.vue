<template>
  <div id="app">
    <img src="./assets/logo.png">
    <!-- 通过路由：让请求localhost:8080/时 自动访问HelloWorl组件-->
    <router-view/>
    <HelloWorld></HelloWorld>
  <HelloWorld></HelloWorld>
    <HelloWorld></HelloWorld>
    <!--直接引入HelloWorld组件
      1.引入文件import HelloWorld from './components/HelloWorld'
      2.将引入的文件 打成一个组件
      3.以标签形式使用组件  <HelloWorld></HelloWorld>
     -->
  </div>
</template>

<script>
  import HelloWorld from './components/HelloWorld'
  export default {
  name: 'App' ,
  components:{//组件
         HelloWorld
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
