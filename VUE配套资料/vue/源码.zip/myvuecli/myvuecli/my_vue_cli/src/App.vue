<template>
  <div id="app">
    {{$store.state.count}}
    <button @click="countinc">同步+</button>
     <button @click="countincAsync">异步+</button>
      是否成年： {{$store.getters.isAudlt}}
      是否成年： {{vueIsAudlt}}
    <img src="./assets/logo.png">
  </div>
</template>

<script>
  export default{

    methods:{
        countinc(){
          //$store是一个全局对象
         return   this.$store.dispatch('actincrease')
        },
        countincAsync(){
            return   this.$store.dispatch('asyncincrease')
        }

    },

    computed:{
        vueIsAudlt(){
          return this.$store.getters.isAudlt ;
        }

    }

  }

</script>